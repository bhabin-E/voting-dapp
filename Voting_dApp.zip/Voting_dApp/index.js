//Metamask Connection 
contractAddress = '0x2006A99e304Aba3A7959383f29eB4982b3497A44';
const abi = [
	{
		"inputs": [
			{
				"internalType": "string",
				"name": "_name",
				"type": "string"
			}
		],
		"name": "addCandidate",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "address",
				"name": "_voter",
				"type": "address"
			}
		],
		"name": "addVoter",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [],
		"stateMutability": "nonpayable",
		"type": "constructor"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "_candidateIndex",
				"type": "uint256"
			}
		],
		"name": "vote",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": true,
				"internalType": "address",
				"name": "voter",
				"type": "address"
			},
			{
				"indexed": true,
				"internalType": "uint256",
				"name": "candidateIndex",
				"type": "uint256"
			}
		],
		"name": "VoteCast",
		"type": "event"
	},
	{
		"inputs": [],
		"name": "admin",
		"outputs": [
			{
				"internalType": "address",
				"name": "",
				"type": "address"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "candidateCount",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"name": "candidates",
		"outputs": [
			{
				"internalType": "string",
				"name": "name",
				"type": "string"
			},
			{
				"internalType": "uint256",
				"name": "voteCount",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "_index",
				"type": "uint256"
			}
		],
		"name": "getCandidate",
		"outputs": [
			{
				"internalType": "string",
				"name": "name",
				"type": "string"
			},
			{
				"internalType": "uint256",
				"name": "voteCount",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "getTamilNaduHashedAddresses",
		"outputs": [
			{
				"internalType": "bytes32[]",
				"name": "",
				"type": "bytes32[]"
			}
		],
		"stateMutability": "pure",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "getWinnerAndRunnerUp",
		"outputs": [
			{
				"internalType": "string",
				"name": "winner",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "runnerUp",
				"type": "string"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "address",
				"name": "",
				"type": "address"
			}
		],
		"name": "hashedVoters",
		"outputs": [
			{
				"internalType": "bool",
				"name": "",
				"type": "bool"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "totalVotes",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "address",
				"name": "",
				"type": "address"
			}
		],
		"name": "voters",
		"outputs": [
			{
				"internalType": "bool",
				"name": "",
				"type": "bool"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "votingAge",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	}
];

let contract; 
let tamilNaduElection; 

window.addEventListener('load', async () => {
    // Check if MetaMask is installed
    if (window.ethereum) {
        window.web3 = new Web3(window.ethereum);
        try {
            await window.ethereum.request({ method: 'eth_requestAccounts' });
            tamilNaduElection = new web3.eth.Contract(abi, contractAddress);

            // Display date,time & temperature
            showDateTime();
            showTemperature();
        } catch (error) {
            console.error('User denied account access:', error);
            alert('Please allow access to your Ethereum account to use this dApp');
        }
    } else {
        alert('Please install MetaMask to use this dApp');
    }
});

let selectedCandidateIndex = null;

function selectCandidate(candidateIndex) {
    selectedCandidateIndex = candidateIndex;
    const candidateCards = document.querySelectorAll('.candidate-card');
    candidateCards.forEach((card, index) => {
        card.style.opacity = index === candidateIndex ? '0.5' : '1';
    });

    document.getElementById('vote-button').disabled = false;
}

async function castVote() {
    try {
        if (selectedCandidateIndex === null || selectedCandidateIndex < 0 || selectedCandidateIndex >= 10) {
            throw new Error("Invalid candidate index");
        }
        console.log('Casting vote for candidate index:', selectedCandidateIndex);

        const accounts = await web3.eth.getAccounts();
        const voter = accounts[0];
        console.log('Voter address:', voter);

        await tamilNaduElection.methods.vote(selectedCandidateIndex).send({ from: voter });
        
        alert('Vote cast successfully!');
        document.getElementById('vote-button').disabled = true;
        selectedCandidateIndex = null;

    } catch (error) {
        console.error('Error casting vote:', error);
        alert('Failed to cast vote. ' + error.message);
    }
}

// Close poll only access by site admin 
function closePoll() {
    const password = prompt("!!! ADMIN ONLY !!!  Please enter the password to close the poll:");
    if (password === "TECHBLOCK") { 
        alert("Poll closed successfully!");
        const closePollButton = document.getElementById('close-poll-button');
        closePollButton.parentNode.removeChild(closePollButton);
    } else {
        alert("Incorrect password. Poll could not be closed.");
    }
}

// Function to display winner 
async function displayWinner() {
    try {
        const winnerIndex = await tamilNaduElection.methods.getWinner().call();
        const winnerInfo = await tamilNaduElection.methods.getCandidate(winnerIndex).call();
        const winnerName = winnerInfo[0];
        const winnerVotes = winnerInfo[1];
        
        const winnerContainer = document.getElementById('winner-container');
        winnerContainer.innerHTML = `
            <div class="winner-info">
                <h2>Winner: ${winnerName}</h2>
                <p>Votes: ${winnerVotes}</p>
                <!-- Add image display if available -->
            </div>
        `;
    } catch (error) {
        console.error('Error displaying winner:', error);
        alert('Failed to display winner. ' + error.message);
    }
}

// Function to display other candidates 
async function displayOtherCandidates() {
    try {
        const candidateCount = await tamilNaduElection.methods.getCandidateCount().call();
        let candidates = [];
        for (let i = 0; i < candidateCount; i++) {
            const candidateInfo = await tamilNaduElection.methods.getCandidate(i).call();
            candidates.push({ name: candidateInfo[0], votes: candidateInfo[1] });
        }
        candidates.sort((a, b) => b.votes - a.votes);
        
        const otherCandidatesContainer = document.getElementById('other-candidates-container');
        otherCandidatesContainer.innerHTML = '';
        candidates.forEach(candidate => {
            if (candidate.name !== winnerName) {
                otherCandidatesContainer.innerHTML += `
                    <div class="other-candidate">
                        <p>Name: ${candidate.name}</p>
                        <p>Votes: ${candidate.votes}</p>
                        <!-- Add image display if available -->
                    </div>
                `;
            }
        });
    } catch (error) {
        console.error('Error displaying other candidates:', error);
        alert('Failed to display other candidates. ' + error.message);
    }
}

function showDateTime() {
    const dateTimeContainer = document.getElementById('date-time-container');
    function updateTime() {
        const now = new Date();
        const dateTimeString = now.toLocaleString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric', hour12: true });
        dateTimeContainer.textContent = dateTimeString;
    }
    updateTime();
    setInterval(updateTime, 1000); 
}

function showTemperature() {
    const temperature = Math.floor(Math.random() * (38 - 22 + 1)) + 22;
    document.getElementById('temperature').innerHTML = `<span id="temperature-value">Temperature: ${temperature}°C</span>`;
}

const languageData = {
    'en': {
        'electionTitle': 'Tamil Nadu Election',
        'voteFormTitle': 'Vote for a Candidate',
        'voteButton': 'Vote'
    },
    'ta': {
        'electionTitle': 'தமிழ்நாடு தேர்தல்',
        'voteFormTitle': 'ஒரு வேட்பாளருக்கு வாக்களியுங்கள்',
        'voteButton': 'வாக்களி'
    }
};

let currentLanguage = 'ta';

function switchLanguage(lang) {
    currentLanguage = lang;
    updateLanguageUI();
}

function updateLanguageUI() {
    const langData = languageData[currentLanguage];
    document.getElementById('election-title').textContent = langData['electionTitle'];
    document.getElementById('vote-form-title').textContent = langData['voteFormTitle'];
    document.getElementById('vote-button').textContent = langData['voteButton'];
}